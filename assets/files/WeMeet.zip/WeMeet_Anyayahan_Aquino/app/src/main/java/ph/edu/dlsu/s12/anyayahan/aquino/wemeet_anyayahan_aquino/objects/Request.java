package ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects;

public class Request {
    private String requester;
    private String requestee;
    private String requester_fullname;
    private String icon = "default";

    public String getRequester() {
        return requester;
    }

    public void setRequester(String requester) {
        this.requester = requester;
    }

    public String getRequestee() {
        return requestee;
    }

    public void setRequestee(String requestee) {
        this.requestee = requestee;
    }

    public String getRequester_fullname() {
        return requester_fullname;
    }

    public void setRequester_fullname(String requester_fullname) {
        this.requester_fullname = requester_fullname;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }
}

