package ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

//import com.google.firebase.FirebaseApp;

public class MainActivity extends AppCompatActivity {
    private EditText username;
    private EditText password;
    private String uname;
    private String pw;
    private Button login;
    private TextView register;
    private FirebaseAuth auth;
    private FirebaseUser user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


//        FirebaseApp.initializeApp(this);
        init();

        user = FirebaseAuth.getInstance().getCurrentUser();

        if(user != null){
            startActivity(new Intent(MainActivity.this, home_page.class));
            finish();
        }

    }

    private void init() {
        login = findViewById(R.id.login);
        register = findViewById(R.id.register_btn);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);

        auth = FirebaseAuth.getInstance();

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uname = username.getText().toString();
                pw = password.getText().toString();

                if(TextUtils.isEmpty(uname) || TextUtils.isEmpty(pw)){
                    Toast.makeText(MainActivity.this, "Please fill up fields" , Toast.LENGTH_SHORT).show();
                }
                else{
                    auth.signInWithEmailAndPassword(uname, pw).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()){
                                Intent intent = new Intent(MainActivity.this, home_page.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK| Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                                finish();
                            }
                            else{
                                DatabaseReference user = FirebaseDatabase.getInstance("https://wemeet-db7a0-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference("myUsers");
                                //error here
                                Boolean go = false;

                                if(uname.contains(".") || uname.contains("#") || uname.contains("$") || uname.contains("[") || uname.contains("]")){
                                    Toast.makeText(MainActivity.this, "Wrong input or password" , Toast.LENGTH_SHORT).show();
                                }
                                else{
                                    user.child(uname).addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                            if(snapshot.exists()){
                                                auth.signInWithEmailAndPassword(snapshot.child("email").getValue().toString(),pw).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                                                    @Override
                                                    public void onSuccess(AuthResult authResult) {
                                                        Intent intent = new Intent(MainActivity.this, home_page.class);
                                                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK| Intent.FLAG_ACTIVITY_NEW_TASK);
                                                        startActivity(intent);
                                                        finish();
                                                    }
                                                });
                                            }
                                            else{
                                                Toast.makeText(MainActivity.this, "Wrong input and password" , Toast.LENGTH_SHORT).show();
                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {

                                        }
                                    });
                                }
                            }
                        }
                    });
                }

            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Register.class));
            }
        });
    }
}