package ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.adapters.messageAdapter;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.Message;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.Room;

public class conversation extends AppCompatActivity {

    private Button send_btn;
    private ImageView audio;
    private Intent myFileIntent;
    private TextView message_txt;
    private EditText message;
    private TextView room_cat;
    private TextView room_code;

    private FirebaseDatabase fdb;
    private DatabaseReference mydb;


    private RecyclerView message_list;
    private ArrayList<Message> messageList;
    private Message msg;
    private FirebaseUser user;
    String username;
    private ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.adapters.messageAdapter msgAdapter;

    private String room_id;
    private String path = null;
    private Uri uriPath;
    private FirebaseStorage storage = FirebaseStorage.getInstance("gs://wemeet-db7a0.appspot.com/");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conversation);


        user = FirebaseAuth.getInstance().getCurrentUser();

        msg = new Message();
        messageList = new ArrayList<>();
        //From past room
        room_id = getIntent().getStringExtra("room_id");


        fdb = FirebaseDatabase.getInstance("https://wemeet-db7a0-default-rtdb.asia-southeast1.firebasedatabase.app/");
        init();

        //message_txt.setText(snapshot.getValue().toString());

        DatabaseReference db = fdb.getReference("rooms");

        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for(DataSnapshot snaphot1 : snapshot.getChildren()){
                    Room rm = snaphot1.getValue(Room.class);
                    if(rm.getId().equals(room_id)){
                        room_cat.setText(rm.getCategory());
                        if(!rm.getCode().equals("empty")){
                            room_code.setText("Code: "+ rm.getCode());
                        }
                        else{
                            room_code.setText("Public room");
                        }
                    }
                }



            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        DatabaseReference userdb = fdb.getReference("myUsers").child(user.getUid()).child("username");
        userdb.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                username = snapshot.getValue().toString();
                mydb = fdb.getReference("messages");
                mydb.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot1) {
                        messageList.clear();
                        int i = 0;
                        for(DataSnapshot snaphot2 : snapshot1.getChildren()){

                            if(room_id.equals(snaphot2.getValue(Message.class).getRoom_id())){
                                msg = snaphot2.getValue(Message.class);
                                if(username.equals(msg.getSender()))
                                    msg.setPosition(1);
                                messageList.add(messageList.size(), msg);
                                i++;
                            }

                        }
                        msgAdapter = new messageAdapter(messageList, conversation.this);
                        message_list.setAdapter(msgAdapter);
                        message_list.scrollToPosition(messageList.size() - 1);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        message_txt.setText("CANCELLED");
                    }
                });


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



        send_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(uriPath != null){
                    uploadFile(uriPath);
                    message.setEnabled(false);
                }
                else{
                    Message new_msg = new Message();
                    new_msg.setSender(username);
                    new_msg.setRoom_id(room_id);
                    new_msg.setMessage(message.getText().toString());
                    DateFormat df = new SimpleDateFormat("yyMMddHHmmssZ");
                    String date = df.format(Calendar.getInstance().getTime());
                    DatabaseReference dbref = fdb.getReference("messages");
                    //fix id
                    dbref.child(date + room_id).setValue(new_msg);

                    message.setText("");
                }
            }
        });





//        DatabaseReference roomdb = fdb.getReference("rooms").child(room_id).child("category");
//        roomdb.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });

    }

    private void uploadFile(Uri uriPath) {
        String fileName = System.currentTimeMillis()+"";
        StorageReference storageReference = storage.getReference();
        storageReference.child("audio").child(fileName).putFile(uriPath).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                while(!uriTask.isComplete());
                Uri uri = uriTask.getResult();

                Message new_msg = new Message();
                new_msg.setAudioURL(uri.toString());
                new_msg.setSender(username);
                new_msg.setRoom_id(room_id);
                new_msg.setMessage(message.getText().toString());
                DateFormat df = new SimpleDateFormat("yyMMddHHmmssZ");
                String date = df.format(Calendar.getInstance().getTime());
                DatabaseReference dbref = fdb.getReference("messages");
                //fix id
                dbref.child(date + room_id).setValue(new_msg);

                message.setText("");
            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                double progress = (100.0*snapshot.getBytesTransferred())/snapshot.getTotalByteCount();
            }
        });
    }


    private void init() {



        this.send_btn = findViewById(R.id.send_btn);
//        this.message_txt = findViewById(R.id.message_txt);
        this.message = findViewById(R.id.message);

        message_list  = findViewById(R.id.message_list);

        message_list.setLayoutManager(new LinearLayoutManager(this));

        this.room_cat = findViewById(R.id.room_cat);
        this.room_code = findViewById(R.id.room_code);

        this.audio = findViewById(R.id.audio);
        this.audio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myFileIntent = new Intent(Intent.ACTION_GET_CONTENT);
                myFileIntent.setType("*/*");
                startActivityForResult(myFileIntent, 10);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 10:
                path = data.getData().getPath();
                String substr = path.substring(path.length() - 3);
                if(substr.equals("mp3") || substr.equals("MP3") || substr.equals("Mp3")){
                    uriPath = data.getData();
                    message.setText(path);
                    message.setEnabled(false);
                }
                else{
                    Toast.makeText(this, "Please choose MP3 file", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }
}