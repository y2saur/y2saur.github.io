package ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;

import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.User;

public class Register extends AppCompatActivity {
    private Boolean first = false;
    private String lastname;
    private String firstname;
    private Date birthday;
    private String bday;
    private String email;
    private String username;
    private String password;
    private String confirm_pw;
    private EditText email_txt;
    private EditText fname_txt;
    private EditText lname_txt;
    private EditText date_txt;
    private EditText confirm_txt;
    private EditText username_txt;
    private EditText password_txt;
    private Button register;
    private FirebaseAuth auth;
    private DatabaseReference mydb = FirebaseDatabase.getInstance("https://wemeet-db7a0-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference();
    private DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);



        auth = FirebaseAuth.getInstance();
        init();
    }

    private void init() {
        this.lname_txt = findViewById(R.id.l_name);
        this.fname_txt = findViewById(R.id.f_name);
        this.confirm_txt = findViewById(R.id.confirm_pw);
        this.email_txt = findViewById(R.id.email);
        this.username_txt = findViewById(R.id.username);
        this.password_txt = findViewById(R.id.password);
        this.register = findViewById(R.id.regist_btn);

        register.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                firstname = fname_txt.getText().toString();
                lastname = lname_txt.getText().toString();
                email = email_txt.getText().toString();
                username = username_txt.getText().toString();
                password = password_txt.getText().toString();
                confirm_pw = confirm_txt.getText().toString();
//                //birthday
//                bday = (date_txt.getText().toString());
//                try {
//                    birthday = formatter.parse(bday);
//                    bday = new SimpleDateFormat("dd/MM/yyyy").format(birthday);
//
//
//                } catch (ParseException e) {
//                    e.printStackTrace();
//                }




                //Check fields
                DatabaseReference users = FirebaseDatabase.getInstance("https://wemeet-db7a0-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference("myUsers");
                users.child(username).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists()){
                            Toast.makeText(Register.this, username + " is taken!" , Toast.LENGTH_SHORT).show();
                        }
                        else{
                            if(password.equals(confirm_pw)){
                                //check if username exists
                                mydb.child("myUsers").addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        first = false;
                                        User temp_user = new User();
                                        for(DataSnapshot ss : snapshot.getChildren()){
                                            temp_user = ss.getValue(User.class);
                                            if(username.equals(temp_user.getUsername())){
                                                first = true;
                                            }
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {

                                    }
                                });
                            }
                            else{
                                Toast.makeText(Register.this, "Password does not match" , Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

                if(first){
                    Toast.makeText(Register.this, "Username is already taken", Toast.LENGTH_SHORT).show();
                }
                else{
                    first = false;
                    registerNow(username, email, password);
                }
                //registerNow(username, email, password);
            }
        });

    }


    private void registerNow(final String username, String email, String password){
        auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    FirebaseUser firebaseUser = auth.getCurrentUser();
                    String userid = firebaseUser.getUid();

                    mydb = FirebaseDatabase.getInstance("https://wemeet-db7a0-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference("myUsers").child(username);

                    //Hashmap
                    HashMap<String, String> hashMap = new HashMap<>();
                    hashMap.put("id", userid);
                    hashMap.put("firstname", firstname);
                    hashMap.put("lastname", lastname);
                    hashMap.put("email", email);
                    hashMap.put("username", username);
                    hashMap.put("imageURL", "default");
                    hashMap.put("bio", "");
                    hashMap.put("interests", "");

                    //Opening Main activity
                    mydb.setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {

                            if(task.isSuccessful()){
                                auth.signInWithEmailAndPassword(email,password);
                                Intent intent = new Intent(Register.this, home_page.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK| Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                                finish();
                            }
                        }
                    });
                }
                else{
                    Toast.makeText(Register.this, "Invalid Email or password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}