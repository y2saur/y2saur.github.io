package ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import org.w3c.dom.Text;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.UUID;

import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.Message;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.Request;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.Room;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.User;

public class view_profile extends AppCompatActivity {
    private Button add;
    private Button edit;
    private Button save;
    private TextView firstname;
    private TextView lastname;
    private TextView about;
    private TextView interest;
    private EditText about_text;
    private EditText interest_text;
    private TextView header;
    private ImageView upload;
    private ImageView avatar;

    private FirebaseDatabase mydb = FirebaseDatabase.getInstance("https://wemeet-db7a0-default-rtdb.asia-southeast1.firebasedatabase.app/");
    private User user;
    private FirebaseUser userAuth = FirebaseAuth.getInstance().getCurrentUser();
    private String userEmail;

    private Uri filePath;

    private final int PICK_IMAGE_REQUEST = 71;

    FirebaseStorage storage;
    StorageReference storageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_profile);
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        userEmail = userAuth.getEmail();
        DatabaseReference db = mydb.getReference("myUsers");
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for(DataSnapshot snaphot1 : snapshot.getChildren()){
                    User temp_user = snaphot1.getValue(User.class);
                    if(temp_user.getEmail().equals(userEmail)){
                        user = temp_user;
                        firstname.setText(temp_user.getFirstname());
                        lastname.setText(temp_user.getLastname());
                        about.setText(temp_user.getBio());
                        interest.setText(temp_user.getInterests());
                    }

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        init();
    }
    private void chooseImage(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null )
        {
            filePath = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                avatar.setImageBitmap(bitmap);
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }

    private void uploadImage() {

        if(filePath != null)
        {
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Uploading...");
            progressDialog.show();

                StorageReference ref = storageReference.child("images/"+ UUID.randomUUID().toString());
            ref.putFile(filePath)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            progressDialog.dismiss();
                            Toast.makeText(view_profile.this, "Uploaded", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();
                            Toast.makeText(view_profile.this, "Failed "+e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0*taskSnapshot.getBytesTransferred()/taskSnapshot
                                    .getTotalByteCount());
                            progressDialog.setMessage("Uploaded "+(int)progress+"%");
                        }
                    });
        }
    }

    private void init() {
        this.firstname = findViewById(R.id.firstname);
        this.lastname = findViewById(R.id.lastname);
        this.add = findViewById(R.id.button);
        this.edit = findViewById(R.id.edit_btn);
        this.about = findViewById(R.id.text_about);
        this.interest = findViewById(R.id.text_interest);
        this.about_text = findViewById(R.id.edit_about);
        this.interest_text = findViewById(R.id.edit_interests);
        this.save = findViewById(R.id.save_btn);
        this.header = findViewById(R.id.header_edit);
        this.upload = findViewById(R.id.btn_upload);
        this.avatar = findViewById(R.id.avatar);

        String self = getIntent().getStringExtra("self");

        if(self.equals("true")){
            add.setVisibility(View.GONE);
            save.setVisibility(View.GONE);
            about_text.setVisibility(View.GONE);
            interest_text.setVisibility(View.GONE);
            upload.setVisibility(View.INVISIBLE);

            edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    //Set Visibility of the components
                    about_text.setVisibility(View.VISIBLE);
                    interest_text.setVisibility(View.VISIBLE);
                    save.setVisibility(View.VISIBLE);
                    edit.setVisibility(View.INVISIBLE);
                    about.setVisibility(View.GONE);
                    interest.setVisibility(View.GONE);
                    upload.setVisibility(View.VISIBLE);

                    //change header
                    header.setText("Edit Profile");

                    //set text in Edit Text field
                    String about1 = about.getText().toString();
                    String interest1 = interest.getText().toString();
                    about_text.setText(about1);
                    interest_text.setText(interest1);
                }
            });

            upload.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    chooseImage();
                }
            });

            save.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //change header
                    header.setText("User Profile");

                    about.setVisibility(View.VISIBLE);
                    interest.setVisibility(View.VISIBLE);

                    about.setText(about_text.getText().toString());
                    user.setBio(about_text.getText().toString());
                    interest.setText(interest_text.getText().toString());
                    user.setInterests(interest_text.getText().toString());

                    about_text.setVisibility(View.GONE);
                    interest_text.setVisibility(View.GONE);
                    edit.setVisibility(View.VISIBLE);
                    add.setVisibility(View.GONE);
                    save.setVisibility(View.GONE);
                    upload.setVisibility(View.GONE);

                    DatabaseReference db = mydb.getReference("myUsers");
                    db.child(user.getId()).setValue(user);

                    uploadImage();
                }
            });
        }
        else{
            edit.setVisibility(View.GONE);
            about_text.setVisibility(View.GONE);
            interest_text.setVisibility(View.GONE);
            save.setVisibility(View.GONE);
            String friend_uname = getIntent().getStringExtra("friend_uname");
            //Get user information
            DatabaseReference dbref = mydb.getReference("myUsers");
            dbref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    User temp_user = new User();
                    for(DataSnapshot snaphot1 : snapshot.getChildren()){
                        temp_user = snaphot1.getValue(User.class);
                        if(temp_user.getUsername().equals(friend_uname)){
                            user = temp_user;
                            firstname.setText(temp_user.getFirstname());
                            lastname.setText(temp_user.getLastname());
                            about.setText(temp_user.getBio());
                            interest.setText(temp_user.getInterests());
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });



            //Check if already friend

            //Else view add user button

            DatabaseReference check_req = mydb.getReference("friendRequests");
            check_req.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    Request temp_req = new Request();
                    for(DataSnapshot snaphot1 : snapshot.getChildren()){
                        temp_req = snaphot1.getValue(Request.class);
                        if(temp_req.getRequester().equals(user.getUsername()) && temp_req.getRequestee().equals(friend_uname)){
                            add.setVisibility(View.INVISIBLE);
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });


            add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    add.setVisibility(View.INVISIBLE);
                    userEmail = userAuth.getEmail();
                    DatabaseReference db = mydb.getReference("myUsers");
                    db.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            String friend_uname = getIntent().getStringExtra("friend_uname");
                            Request req = new Request();
                            req.setRequestee(friend_uname);

                            for(DataSnapshot snaphot1 : snapshot.getChildren()){
                                User temp_user = snaphot1.getValue(User.class);
                                if(temp_user.getEmail().equals(userEmail)){
                                    req.setRequester(temp_user.getUsername());
                                    req.setRequester_fullname(temp_user.getFirstname() + " " + temp_user.getLastname());
                                }
                            }

                            DateFormat df = new SimpleDateFormat("yyMMddHHmmssZ");
                            String date = df.format(Calendar.getInstance().getTime());
                            DatabaseReference dbref = mydb.getReference("friendRequests");
                            //fix id
                            dbref.child("REQ" + date).setValue(req);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            });
        }

    }
}