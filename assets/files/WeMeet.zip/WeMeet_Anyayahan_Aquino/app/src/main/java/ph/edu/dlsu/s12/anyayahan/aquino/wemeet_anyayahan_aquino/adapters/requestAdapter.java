package ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.adapters;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.R;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.conversation;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.Friendship;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.Request;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.Room;

public class requestAdapter extends RecyclerView.Adapter<requestAdapter.RequestViewHolder> {


    private ArrayList<Request> requestArrayList;
    private Activity main;
    public requestAdapter(ArrayList<Request> requestArrayList, Activity activity){
        this.requestArrayList = requestArrayList;
        this.main = activity;
    }

    @Override
    public int getItemCount() {
        return requestArrayList.size();
    }

    @Override
    public RequestViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.friend_card, parent, false);

        RequestViewHolder requestViewHolder = new RequestViewHolder(view);

        return requestViewHolder;
    }


    @Override
    public void onBindViewHolder(final requestAdapter.RequestViewHolder holder, int position) {
        holder.fullname.setText(requestArrayList.get(position).getRequester_fullname());
        holder.username.setText(requestArrayList.get(position).getRequester());
        holder.decline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseDatabase fdb = FirebaseDatabase.getInstance("https://wemeet-db7a0-default-rtdb.asia-southeast1.firebasedatabase.app/");
                DatabaseReference request = fdb.getReference("friendRequests");
                request.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Request req = new Request();
                        for(DataSnapshot ss : snapshot.getChildren()){
                            req = ss.getValue(Request.class);
                            if(req.getRequestee().equals(requestArrayList.get(position).getRequestee()) && req.getRequester().equals(requestArrayList.get(position).getRequester())){

                                Toast.makeText(main, ss.getKey(), Toast.LENGTH_SHORT).show();
                                request.child(ss.getKey()).setValue(null);
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });

        holder.accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FirebaseDatabase fdb = FirebaseDatabase.getInstance("https://wemeet-db7a0-default-rtdb.asia-southeast1.firebasedatabase.app/");
                DatabaseReference request = fdb.getReference("friendRequests");
                request.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Request req = new Request();
                        for(DataSnapshot ss : snapshot.getChildren()){
                            req = ss.getValue(Request.class);
                            if(req.getRequestee().equals(requestArrayList.get(position).getRequestee()) && req.getRequester().equals(requestArrayList.get(position).getRequester())){

                                Toast.makeText(main, ss.getKey(), Toast.LENGTH_SHORT).show();
                                request.child(ss.getKey()).setValue(null);
                            }
                        }

                        Friendship friendship = new Friendship();
                        friendship.setFriend1(requestArrayList.get(position).getRequestee());
                        friendship.setFriend2(requestArrayList.get(position).getRequester());
                        DateFormat df = new SimpleDateFormat("yyMMddHHmmssZ");
                        String date = df.format(Calendar.getInstance().getTime());
                        DatabaseReference friends = fdb.getReference("friendships");
                        friends.child("FRND" + date).setValue(friendship);
                        Toast.makeText(main, "Friend Accepted!", Toast.LENGTH_SHORT).show();

                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });
//        holder.category.setText(requestArrayList.get(position).getCategory());
//        holder.created_by.setText("Created by: " + requestArrayList.get(position).getCreated_by());
//        holder.join_btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(main, conversation.class);
//                intent.putExtra("room_id", roomArrayList.get(position).getId());
//                main.startActivity(intent);
//            }
//        });
    }

    protected class RequestViewHolder extends RecyclerView.ViewHolder{
        ImageView img;
        TextView fullname;
        TextView username;
        Button accept;
        Button decline;


        public RequestViewHolder(View view) {
            super(view);
            img = view.findViewById(R.id.imageView);
            fullname = view.findViewById(R.id.text_username);
            username = view.findViewById(R.id.text_name);
            accept = view.findViewById(R.id.btn_accept);
            decline = view.findViewById(R.id.btn_decline);
        }
    }


}