package ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.adapters.categoryAdapter;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.adapters.requestAdapter;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.Request;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.Room;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.User;

public class friend_requests extends AppCompatActivity {

    private RecyclerView request_list;
    private ArrayList<Request> requestList;
    private ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.adapters.requestAdapter requestAdapter;
    private FirebaseDatabase mydb = FirebaseDatabase.getInstance("https://wemeet-db7a0-default-rtdb.asia-southeast1.firebasedatabase.app/");
    private FirebaseUser userAuth = FirebaseAuth.getInstance().getCurrentUser();
    private String username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend_requests);



        DatabaseReference users = mydb.getReference("myUsers");
        users.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for(DataSnapshot ss : snapshot.getChildren()){
                    User temp_user = ss.getValue(User.class);
                    if(temp_user.getEmail().equals(userAuth.getEmail())){
                        username = temp_user.getUsername();
                    }
                }

                DatabaseReference requests = mydb.getReference("friendRequests");
                requests.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        init();
                        requestList.clear();
                        for(DataSnapshot ss2 : snapshot.getChildren()){
                            Request temp_req = ss2.getValue(Request.class);
                            if(temp_req.getRequestee().equals(username)){
                                //add to array list
                                requestList.add(temp_req);
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    private void init() {
        requestList = new ArrayList<>();
        request_list = findViewById(R.id.friend_list);
        request_list.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        requestAdapter = new requestAdapter(requestList, friend_requests.this);
        request_list.setAdapter(requestAdapter);

    }
}