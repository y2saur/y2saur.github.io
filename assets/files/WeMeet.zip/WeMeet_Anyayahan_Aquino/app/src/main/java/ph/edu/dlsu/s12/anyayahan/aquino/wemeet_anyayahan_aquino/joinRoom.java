package ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class joinRoom extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_private_room);
    }
}