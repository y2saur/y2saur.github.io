package ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.adapters;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import static android.os.Environment.DIRECTORY_DOWNLOADS;

import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;

import org.w3c.dom.Text;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.MainActivity;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.R;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.home_page;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.Message;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.Room;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.conversation;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.view_profile;

import static androidx.core.content.ContextCompat.startActivity;

public class messageAdapter extends RecyclerView.Adapter<messageAdapter.messageViewHolder>{


//    private static final String DIRECTORY_DOWNLOADS = new String(Environment.getExternalStorageState());;
    private ArrayList<Message> messageArrayList;
    public Activity activity;
    public messageAdapter(ArrayList<Message> messageArrayList, Activity act){
        this.messageArrayList = messageArrayList;
        this.activity = act;
    }

    @Override
    public int getItemCount() {
        return messageArrayList.size();
    }

    @Override
    public messageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_msg, parent, false);

        messageViewHolder messageViewHolder = new messageViewHolder(view);

        return messageViewHolder;
    }


    @Override
    public void onBindViewHolder(final messageAdapter.messageViewHolder holder, int position) {

        int pos;
        pos = messageArrayList.get(position).getPosition();

        if(!messageArrayList.get(position).getAudioURL().equals("")){
            if(pos == 0){
                holder.right.setVisibility(View.GONE);
                holder.right_audio.setVisibility(View.GONE);
                holder.left_message.setVisibility(View.GONE);
                holder.left_mic.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        downloadFile(activity, "AUDIO", ".mp3", DIRECTORY_DOWNLOADS, messageArrayList.get(position).getAudioURL());
                        Toast.makeText(activity, "Download file", Toast.LENGTH_SHORT).show();
                    }
                });
            }
            else{holder.left.setVisibility(View.GONE);
                holder.left_audio.setVisibility(View.GONE);
                holder.right_message.setVisibility(View.GONE);
                holder.right_mic.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DateFormat df = new SimpleDateFormat("yyMMddHHmm");
                        String date = df.format(Calendar.getInstance().getTime());
                        downloadFile(activity,"wemeet" + date, ".mp3", DIRECTORY_DOWNLOADS, messageArrayList.get(position).getAudioURL());
                        Toast.makeText(activity, "Download file", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }
        else{
            if(pos == 0){
                holder.left_audio.setVisibility(View.GONE);
                holder.right_audio.setVisibility(View.GONE);

                //left
                holder.right.setVisibility(View.GONE);
                holder.left_sender.setText(messageArrayList.get(position).getSender());
                holder.left_message.setText(messageArrayList.get(position).getMessage());
                holder.left_icon.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showPopup(v, messageArrayList.get(position).getSender());
                    }
                });
//            holder.left_icon.setImageResource(Integer.parseInt(messageArrayList.get(position).getIcon()));
            }
            else{
                holder.left_audio.setVisibility(View.GONE);
                holder.right_audio.setVisibility(View.GONE);
                //right
                holder.left.setVisibility(View.GONE);
                holder.right_sender.setText(messageArrayList.get(position).getSender());
                holder.right_message.setText(messageArrayList.get(position).getMessage());
//            holder.right_icon.setImageResource(Integer.parseInt(messageArrayList.get(position).getIcon()));
            }
        }

    }

    protected class messageViewHolder extends RecyclerView.ViewHolder{
        TextView left_sender;
        TextView left_message;
        ImageView left_icon;
        TextView right_sender;
        TextView right_message;
        ImageView right_icon;
        LinearLayout left;
        LinearLayout right;

        LinearLayout left_audio;
        LinearLayout right_audio;
        ImageView left_mic;
        ImageView right_mic;

        public messageViewHolder(View view) {
            super(view);

            left_sender = view.findViewById(R.id.left_sender);
            left_message = view.findViewById(R.id.left_message);
            left_icon = view.findViewById(R.id.left_icon);
            right_sender = view.findViewById(R.id.right_sender);
            right_message = view.findViewById(R.id.right_message);
            right_icon = view.findViewById(R.id.right_icon);
            left = view.findViewById(R.id.left);
            right = view.findViewById(R.id.right);

            left_audio = view.findViewById(R.id.left_audio);
            right_audio = view.findViewById(R.id.right_audio);
            left_mic = view.findViewById(R.id.left_mic);
            right_mic = view.findViewById(R.id.right_mic);
        }
    }

    private void showPopup(View v, String username) {
        PopupMenu popup = new PopupMenu(activity, v);
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.friend_menu, popup.getMenu());
        Activity act = this.activity;
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()){
                    case R.id.profile : Intent intent = new Intent(activity, view_profile.class);
                        intent.putExtra("self", "false");
                        intent.putExtra("friend_uname", username);
                        act.startActivity(intent);
                        return true;
                }
                return false;
            }
        });
        popup.show();

    }


    public void downloadFile(Context context, String fileName, String fileExtension, String destinationDirectory, String url){
        DownloadManager downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        Uri uri = Uri.parse(url);
        DownloadManager.Request request = new DownloadManager.Request(uri);

        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
//        request.setDestinationInExternalFilesDir(context, destinationDirectory, fileName+fileExtension);
        request.setDestinationInExternalPublicDir(destinationDirectory, fileName+fileExtension);
        downloadManager.enqueue(request);

    }
}
