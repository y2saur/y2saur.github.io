package ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.adapters.friendAdapter;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.adapters.requestAdapter;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.Friendship;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.Request;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.User;

public class friend_list extends AppCompatActivity {

    private RecyclerView friend_list;
    private ArrayList<User> friendList;
    private ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.adapters.friendAdapter friendAdapter;
    private FirebaseDatabase mydb = FirebaseDatabase.getInstance("https://wemeet-db7a0-default-rtdb.asia-southeast1.firebasedatabase.app/");
    private FirebaseUser userAuth = FirebaseAuth.getInstance().getCurrentUser();
    private String username;
    private ArrayList<String> friends;
    private int i = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend_list);

        DatabaseReference users = mydb.getReference("myUsers");
        users.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for(DataSnapshot ss : snapshot.getChildren()){
                    User temp_user = ss.getValue(User.class);
                    if(temp_user.getEmail().equals(userAuth.getEmail())){
                        username = temp_user.getUsername();
                    }
                }
                DatabaseReference requests = mydb.getReference("friendships");
                requests.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        init();
                        friends.clear();
                        Friendship friendship = new Friendship();
                        for(DataSnapshot ss2 : snapshot.getChildren()){
                            friendship = ss2.getValue(Friendship.class);
                            if(friendship.getFriend1().equals(username)){
                                friends.add(friendship.getFriend2());
                            }
                            else if(friendship.getFriend2().equals(username)){
                                friends.add(friendship.getFriend1());
                            }
                        }



                        DatabaseReference friendsDB = mydb.getReference("myUsers");
                        friendsDB.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                setUpAdapter();
                                for(int x = 0 ; x < friends.size(); x++){
                                    for(DataSnapshot snap : snapshot.getChildren()){
                                        String temp_username = friends.get(x);
                                        User user = new User();
                                        user = snap.getValue(User.class);
                                        if(user.getUsername().equals(temp_username)){
                                            friendList.add(user);
                                        }
                                    }
                                }


//                                    Toast.makeText(friend_list.this, "USER:" + user.getUsername(), Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }

    private void init() {
        friends = new ArrayList<>();
    }

    private void setUpAdapter(){
        friendList = new ArrayList<>();
        friend_list = findViewById(R.id.friend_list);
        friend_list.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        friendAdapter = new friendAdapter(friendList, friend_list.this);
        friend_list.setAdapter(friendAdapter);
    }
}