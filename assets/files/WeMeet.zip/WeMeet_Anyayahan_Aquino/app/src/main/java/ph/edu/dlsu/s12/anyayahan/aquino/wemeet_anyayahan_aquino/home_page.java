package ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.zip.Inflater;

import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.adapters.categoryAdapter;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.Room;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.User;

public class home_page extends AppCompatActivity {

    private RecyclerView room_list;
    private RecyclerView myroom_list;
    private ArrayList<Room> roomList;
    private ArrayList<Room> myRooms;
    private ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.adapters.categoryAdapter categoryAdapter;
    private ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.adapters.categoryAdapter categoryAdapter2;
    private ImageView icon;
    private FirebaseDatabase mydb = FirebaseDatabase.getInstance("https://wemeet-db7a0-default-rtdb.asia-southeast1.firebasedatabase.app/");
    private FirebaseUser userAuth = FirebaseAuth.getInstance().getCurrentUser();
    private String username;
    private Room room;
    private Button new_room;
    private Button join_room;
    private Button friend_reqs;
    private Button friend_list;
    private PopupMenu popup;
    private MenuInflater inflater;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);


        DatabaseReference users = mydb.getReference("myUsers");
        users.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot ss : snapshot.getChildren()){
                    User temp_user = ss.getValue(User.class);
                    if(temp_user.getEmail().equals(userAuth.getEmail())){
                        username = temp_user.getUsername();
                    }
                }

                DatabaseReference db = mydb.getReference("rooms");
                room = new Room();
                roomList = new ArrayList<>();
                myRooms = new ArrayList<>();
                db.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        for(DataSnapshot snaphot1 : snapshot.getChildren()){
                            room = snaphot1.getValue(Room.class);
                            if(room.getCreated_by().equals(username) && !room.getCode().equals("empty")){
                                myRooms.add(room);
                            }
                            if(room.getCode().equals("empty")){
                                roomList.add(room);
                            }

                        }

                        init();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }


    private void init() {
        new_room = findViewById(R.id.new_room);
        setRoomBtn();
        join_room = findViewById(R.id.join_room);
        join_room.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(home_page.this, joinRoom.class);
                startActivity(i);
            }
        });
        friend_reqs = findViewById(R.id.friend_requests);
        friend_reqs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(home_page.this, friend_requests.class);
                startActivity(i);
            }
        });
        friend_list = findViewById(R.id.friend_list);
        friend_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(home_page.this, friend_list.class);
                startActivity(i);
            }
        });
        room_list = findViewById(R.id.room_list);
        room_list.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        myroom_list = findViewById(R.id.my_rooms);
        myroom_list.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        categoryAdapter = new categoryAdapter(roomList, home_page.this);
        categoryAdapter2 = new categoryAdapter(myRooms, home_page.this);
        room_list.setAdapter(categoryAdapter);
        myroom_list.setAdapter(categoryAdapter2);
        setUpRecyclerView();

        icon = findViewById(R.id.icon);
        icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showPopup(v);
//                FirebaseAuth.getInstance().signOut();
//                startActivity(new Intent(home_page.this, view_profile.class));
            }
        });
    }

    private void setRoomBtn(){
        new_room.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(home_page.this, create_room.class);
                startActivity(i);
            }
        });
    }


    private void setUpRecyclerView() {
        room_list.setAdapter(categoryAdapter);
        room_list.setLayoutManager(new LinearLayoutManager(this));
//        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new SwipeDelete(categoryAdapter));
//        itemTouchHelper.attachToRecyclerView(order_list);
    }

//    private void retrieve(){
//        DatabaseReference db = mydb.getReference("rooms");
//        room = new Room();
//
//        db.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                room.setCategory(String.valueOf(snapshot.getChildrenCount()));
//                room.setCreated_by("KIKO Aquino");
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//    }
    private void populateList() {


        roomList.add(room);

        room = new Room();
        room.setCategory("HATDOG");
        room.setCreated_by("Jose Aquino");
        roomList.add(room);

        room = new Room();
        room.setCategory("Music");
        room.setCreated_by("Loren Anyayahan");
        roomList.add(room);

        room = new Room();
        room.setCategory("Music");
        room.setCreated_by("Loren Anyayahan");
        roomList.add(room);

        room = new Room();
        room.setCategory("Music");
        room.setCreated_by("Loren Anyayahan");
        roomList.add(room);

        room = new Room();
        room.setCategory("Music");
        room.setCreated_by("Loren Anyayahan");
        roomList.add(room);

        room = new Room();
        room.setCategory("Music");
        room.setCreated_by("Loren Anyayahan");
        roomList.add(room);

        room = new Room();
        room.setCategory("BAKET");
        room.setCreated_by("Loren Anyayahan");
        roomList.add(room);

        room = new Room();
        room.setCategory("Music");
        room.setCreated_by("Loren Anyayahan");
        roomList.add(room);


    }





    private void showPopup(View v) {
        popup = new PopupMenu(this, v);
        inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.menu_list, popup.getMenu());
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()){
                    case R.id.profile : Intent i = new Intent(home_page.this, view_profile.class); i.putExtra("self", "true");
                        startActivity(i); return true;
                    case R.id.logout :   FirebaseAuth.getInstance().signOut();
                        startActivity(new Intent(home_page.this, MainActivity.class)); return true;
                }
                return false;
            }
        });
        popup.show();

    }

}