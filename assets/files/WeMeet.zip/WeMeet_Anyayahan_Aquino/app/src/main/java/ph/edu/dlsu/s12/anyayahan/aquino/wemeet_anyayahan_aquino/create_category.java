package ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.Room;

public class create_category extends AppCompatActivity {
    private EditText category;
    private Button create;
    private String new_cat;
    private String username;
    private FirebaseDatabase fdb;
    private FirebaseUser user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_category);


        user = FirebaseAuth.getInstance().getCurrentUser();
        user.getEmail();

        fdb = FirebaseDatabase.getInstance("https://wemeet-db7a0-default-rtdb.asia-southeast1.firebasedatabase.app/");
        DatabaseReference dbref = fdb.getReference("myUsers").child(user.getUid()).child("username");
        dbref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                init();
                username = snapshot.getValue().toString();

                create.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(!String.valueOf(category.getText()).equals("")){
                            Room room = new Room();
                            new_cat = String.valueOf(category.getText());
                            room.setCategory(new_cat);
                            room.setCreated_by(username);
                            DateFormat df = new SimpleDateFormat("yyMMddHHmmssZ");
                            String date = df.format(Calendar.getInstance().getTime());
                            room.setId(date);
                            DatabaseReference dbref2 = fdb.getReference("rooms");
                            dbref2.child(new_cat).setValue(room);

                            Intent intent = new Intent(create_category.this , conversation.class);
                            intent.putExtra("room_id", room.getId());
                            startActivity(intent);
                        }else{
                            Toast.makeText(create_category.this, "Enter category", Toast.LENGTH_SHORT).show();
                        }

                    }
                });


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



        init();
    }

    private void init() {
        category = findViewById(R.id.category);
        create = findViewById(R.id.button);


    }
}