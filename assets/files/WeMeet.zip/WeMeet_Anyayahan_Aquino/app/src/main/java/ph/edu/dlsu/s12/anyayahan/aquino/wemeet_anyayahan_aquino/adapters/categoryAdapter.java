package ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.adapters;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.R;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.Room;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.conversation;

public class categoryAdapter extends RecyclerView.Adapter<categoryAdapter.GamesViewHolder> {


    private ArrayList<Room> roomArrayList;
    private Activity main;
    public categoryAdapter(ArrayList<Room> roomArrayList, Activity activity){
        this.roomArrayList = roomArrayList;
        this.main = activity;
    }

    @Override
    public int getItemCount() {
        return roomArrayList.size();
    }

    @Override
    public GamesViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.room_card, parent, false);

        GamesViewHolder gamesViewHolder = new GamesViewHolder(view);

        return gamesViewHolder;
    }


    @Override
    public void onBindViewHolder(final categoryAdapter.GamesViewHolder holder, int position) {
        holder.category.setText(roomArrayList.get(position).getCategory());
        holder.created_by.setText("Created by: " + roomArrayList.get(position).getCreated_by());
        holder.join_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(main, conversation.class);
                intent.putExtra("room_id", roomArrayList.get(position).getId());
                main.startActivity(intent);
            }
        });
//        holder.details.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                ArrayList<Item> items;
//                items = orderArrayList.get(position).getItem();
//                Intent intent  = new Intent(main, viewDetails.class);
//                intent.putExtra("item", orderArrayList.get(position));
//                intent.putExtra("items", items);
//                main.startActivity(intent);
//            }
//        });
    }

    protected class GamesViewHolder extends RecyclerView.ViewHolder{
        TextView category;
        TextView created_by;
        Button join_btn;


        public GamesViewHolder(View view) {
            super(view);
            category = view.findViewById(R.id.category);
            created_by = view.findViewById(R.id.created_by);
            join_btn = view.findViewById(R.id.join_btn);
        }
    }


}
