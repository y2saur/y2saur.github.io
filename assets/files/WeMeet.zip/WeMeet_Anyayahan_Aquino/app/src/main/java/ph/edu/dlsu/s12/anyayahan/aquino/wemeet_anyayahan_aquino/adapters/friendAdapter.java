package ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.adapters;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.R;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.Friendship;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.Request;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects.User;
import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.view_profile;

public class friendAdapter extends RecyclerView.Adapter<friendAdapter.FriendViewHolder> {


    private ArrayList<User> friendshipsArrayList;
    private Activity main;

    public friendAdapter(ArrayList<User> friendArrayList, Activity activity){
        this.friendshipsArrayList = friendArrayList;
        this.main = activity;
    }

    @Override
    public int getItemCount() {
        return friendshipsArrayList.size();
    }

    @Override
    public FriendViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.friend, parent, false);

        FriendViewHolder friendViewHolder = new FriendViewHolder(view);

        return friendViewHolder;
    }


    @Override
    public void onBindViewHolder(final friendAdapter.FriendViewHolder holder, int position) {

            holder.fullname.setText(friendshipsArrayList.get(position).getFirstname() + " " + friendshipsArrayList.get(position).getLastname());
            holder.username.setText(friendshipsArrayList.get(position).getUsername());
            holder.view_profile.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(main, view_profile.class);
                    intent.putExtra("self", "false");
                    intent.putExtra("friend_uname", friendshipsArrayList.get(position).getUsername());
                    main.startActivity(intent);
                }
            });
    }

    protected class FriendViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView img;
        TextView fullname;
        TextView username;
        Button view_profile;

        public FriendViewHolder(View view) {
            super(view);
            img = view.findViewById(R.id.imageView);
            fullname = view.findViewById(R.id.text_username);
            username = view.findViewById(R.id.text_name);
            view_profile = view.findViewById(R.id.view_profile);
        }


        @Override
        public void onClick(View v) {

        }
    }

}