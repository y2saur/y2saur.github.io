package ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects;

import java.util.ArrayList;

public class Room {
    private String id;
    private String category;
    private String created_by;
    private String code;

    public Room() {
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
