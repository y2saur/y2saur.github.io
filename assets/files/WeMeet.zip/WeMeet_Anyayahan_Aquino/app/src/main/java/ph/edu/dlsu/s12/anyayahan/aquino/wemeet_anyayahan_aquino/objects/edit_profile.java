package ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.objects;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import ph.edu.dlsu.s12.anyayahan.aquino.wemeet_anyayahan_aquino.R;

public class edit_profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

    }
}